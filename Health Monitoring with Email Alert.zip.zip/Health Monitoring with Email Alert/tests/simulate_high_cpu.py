# This script simulates high CPU usage
while True:
    pass
